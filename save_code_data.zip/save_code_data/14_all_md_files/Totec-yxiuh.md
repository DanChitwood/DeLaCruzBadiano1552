
**Morphemes:**

- Xihuitl/herbs, green leaves

![A_ID188_p110_03_Totec-yxiuh.png](assets/A_ID188_p110_03_Totec-yxiuh.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
