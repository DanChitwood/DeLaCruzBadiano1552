
**Morphemes:**

- Patli/medicine

![D_ID033_p033_01_Ez-patli.png](assets/D_ID033_p033_01_Ez-patli.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  
