
**Morphemes:**

- Papalo/butterfly
- Quilitl/edible green
- Tepe/hill or mountain

![A_ID161_p103_01_Tepe-papalo-quilitl.png](assets/A_ID161_p103_01_Tepe-papalo-quilitl.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
