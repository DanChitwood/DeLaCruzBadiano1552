
**Morphemes:**

- Nochtli/prickly pear

![Z_ID125_p090_01_Tlaloc-nochtli.png](assets/Z_ID125_p090_01_Tlaloc-nochtli.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
