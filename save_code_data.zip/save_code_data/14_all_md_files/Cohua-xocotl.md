
**Morphemes:**

- Xocotl/sour fruit

![M_ID075_p068_04_Cohua-xocotl.png](assets/M_ID075_p068_04_Cohua-xocotl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
