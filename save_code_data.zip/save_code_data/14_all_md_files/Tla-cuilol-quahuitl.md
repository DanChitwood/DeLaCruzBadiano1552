
**Morphemes:**

- Quahuitl/tree or wood
- Tla/thing or something

![M_ID197_p069_01_Tla-cuilol-quahuitl.png](assets/M_ID197_p069_01_Tla-cuilol-quahuitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
