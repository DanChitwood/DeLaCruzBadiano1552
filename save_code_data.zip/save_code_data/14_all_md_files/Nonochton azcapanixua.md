**Variants:**

- nonochton

## Subchapter 7c  

=== "English :flag_us:"
    **For pain at the heart.** For him whose heart pains him or burns, take the plant [nonochton](Nonochton azcapanixua.md) that grows near an ants’ nest, gold, electrum, [teo-xihuitl](Teo-xihuitl v1.md), [chichiltic tapachtli](chichiltic tapachtli.md) and [tetlahuitl](tetlahuitl v2.md), with the burned heart of a deer, and grind them up together in water; let him drink the liquor.  
    [https://archive.org/details/aztec-herbal-of-1552/page/47](https://archive.org/details/aztec-herbal-of-1552/page/47)  


=== "Español :flag_mx:"
    **Para dolor en el corazón.** Aquel cuyo corazón le duele o arde, debe tomar la planta [nonochton](Nonochton azcapanixua.md) que crece cerca de un hormiguero, oro, electro, [teo-xihuitl](Teo-xihuitl v1.md), [chichiltic tapachtli](chichiltic tapachtli.md) y [tetlahuitl](tetlahuitl v2.md), junto con el corazón quemado de un venado, todo triturado en agua; que beba el licor.  

