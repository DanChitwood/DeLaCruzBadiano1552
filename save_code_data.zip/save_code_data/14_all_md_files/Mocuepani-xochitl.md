
**Morphemes:**

- Xochitl/flower

![M_ID119_p067_05_Mocuepani-xochitl.png](assets/M_ID119_p067_05_Mocuepani-xochitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
