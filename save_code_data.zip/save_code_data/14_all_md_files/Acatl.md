
**Morphemes:**

- Acatl/reed

![K_ID002_p079_04_Acatl.png](assets/K_ID002_p079_04_Acatl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
