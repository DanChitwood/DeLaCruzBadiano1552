
**Morphemes:**

- Quahuitl/tree or wood

![M_ID152_p068_01_Temahuitztih-quahuitl.png](assets/M_ID152_p068_01_Temahuitztih-quahuitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
![K_ID152_p069_06_Temahuitztih-quahuitl.png](assets/K_ID152_p069_06_Temahuitztih-quahuitl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
