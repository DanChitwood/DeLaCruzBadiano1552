
**Morphemes:**

- Tonalco/sun or heat
- Xochitl/flower

![M_ID183_p067_06_Tonal-xochitl.png](assets/M_ID183_p067_06_Tonal-xochitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
