
**Morphemes:**

- Quahuitl/tree or wood
- Xocotl/sour fruit

![D_ID142_p032_01_Quauhtla_xoxocoyolin.png](assets/D_ID142_p032_01_Quauhtla_xoxocoyolin.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  
