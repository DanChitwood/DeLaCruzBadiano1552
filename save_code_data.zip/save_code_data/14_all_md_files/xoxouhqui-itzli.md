
**Morphemes:**

- Xocotl/sour fruit

## Subchapter 7h  

=== "English :flag_us:"
    **Antidote.** Against poison let a potion be taken prepared from the leaf and root of the [tonatiuh-yxiuh](Tonatiuh yxiuh v2.md), the root of the [teo-iztaquilitl](Teo-iztaquilitl.md), the [xoxouhqui-itzli](xoxouhqui-itzli.md), the [tonatiuh-yxiuh](Tonatiuh yxiuh v2.md) ahhuachcho, ground together in water, with which are also to be ground up the bright pearl, sardonyx and [xiuh-tomolli](xiuh-tomolli.md).  
    [https://archive.org/details/aztec-herbal-of-1552/page/51](https://archive.org/details/aztec-herbal-of-1552/page/51)  


=== "Español :flag_mx:"
    **Antídoto.** Contra el veneno se debe tomar una poción preparada con la hoja y la raíz del [tonatiuh-yxiuh](Tonatiuh yxiuh v2.md), la raíz del [teo-iztaquilitl](Teo-iztaquilitl.md), el [xoxouhqui-itzli](xoxouhqui-itzli.md), el [tonatiuh-yxiuh](Tonatiuh yxiuh v2.md) ahhuachcho, todo triturado en agua, junto con perla brillante, sardónice y [xiuh-tomolli](xiuh-tomolli.md).  

