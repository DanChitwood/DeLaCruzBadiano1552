![M_ID067_p067_08_Cecen-tlacol.png](assets/M_ID067_p067_08_Cecen-tlacol.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
