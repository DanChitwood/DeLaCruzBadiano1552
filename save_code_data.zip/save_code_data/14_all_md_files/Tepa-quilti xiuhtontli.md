
**Morphemes:**

- Xihuitl/herbs, green leaves

![M_ID159_p067_04_Tepa-quilti_xiuhtontli.png](assets/M_ID159_p067_04_Tepa-quilti_xiuhtontli.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
