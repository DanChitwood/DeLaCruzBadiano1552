
**Morphemes:**

- Atl/water

![D_ID228_p026_01_A-tzitzicaztli.png](assets/D_ID228_p026_01_A-tzitzicaztli.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  
