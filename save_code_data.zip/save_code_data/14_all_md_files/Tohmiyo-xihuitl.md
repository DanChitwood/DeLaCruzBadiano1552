
**Morphemes:**

- Xihuitl/herbs, green leaves

![A_ID177_p111_01_Tohmiyo-xihuitl.png](assets/A_ID177_p111_01_Tohmiyo-xihuitl.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
