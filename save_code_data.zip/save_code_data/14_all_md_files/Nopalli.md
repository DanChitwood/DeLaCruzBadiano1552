**Variants:**

- nohpalli


**Morphemes:**

- Nopalli/nopal


## Subchapter 9p  

=== "English :flag_us:"
    **Inflammations.** An inflamed part of the body will be relieved by a liquor from the [nohpalli](Nopalli.md), [te-amoxtli](Te-amoxtli.md), [tetzmitl](Tetzmitl.md), [eca-patli](Eca-patli.md), [te-xiyotl](Te-xiyotl.md) and [huitz-quilitl](Huitz-quilitl.md), anointing the part thoroughly and rubbing it with honey and yolk of egg.  
    [https://archive.org/details/aztec-herbal-of-1552/page/90](https://archive.org/details/aztec-herbal-of-1552/page/90)  


=== "Español :flag_mx:"
    **Inflamaciones.** Una parte inflamada del cuerpo se alivia con un licor hecho de [nohpalli](Nopalli.md), [te-amoxtli](Te-amoxtli.md), [tetzmitl](Tetzmitl.md), [eca-patli](Eca-patli.md), [te-xiyotl](Te-xiyotl.md) y [huitz-quilitl](Huitz-quilitl.md), untando bien la zona y frotándola con miel y yema de huevo.  

