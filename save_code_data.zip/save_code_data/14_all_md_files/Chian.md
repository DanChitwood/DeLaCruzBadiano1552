## Subchapter 8c  

=== "English :flag_us:"
    **The bladder-wort.** When the flow of the urine is shut off, to open it take the roots of the plants [mamaxtla](Mamaxtla.md) and [cohuanene-pilli](Coanenepilli.md), the tlatlauhqui amoxtli, the very white flower [yollo-xochitl](Yollo-xochitl.md), and the tail of a sucking puppy; grind these up in acrid tasting water, macerate the well-known [chian](Chian.md) seed therein, and administer it. The abdomen is also to be washed out with the root of the herb [ohua-xocoyolin](Ohua-xoxocoyolin.md) crushed in hot water, and the juice given through a clyster. If this medicine avails nothing it will be necessary to take the pith of an extremely slender palm, covered with thin cotton and smeared with honey and the crushed root of the herb [huihuitz-mallotic](Huihuitz-mallotic.md), and this cautiously inserted into the virile member. If this is done the stopped urine will be freed.  
    [https://archive.org/details/aztec-herbal-of-1552/page/59](https://archive.org/details/aztec-herbal-of-1552/page/59)  


=== "Español :flag_mx:"
    **La hierba de vejiga.** Cuando el flujo de la orina se detiene, para abrirlo se toman las raíces de las plantas [mamaxtla](Mamaxtla.md) y [cohuanene-pilli](Coanenepilli.md), el tlatlauhqui amoxtli, la flor muy blanca [yollo-xochitl](Yollo-xochitl.md), y la cola de un perrito lactante; se muelen en agua de sabor acre, se macera allí la semilla conocida [chian](Chian.md) y se administra. También debe lavarse el abdomen con la raíz de la hierba [ohua-xocoyolin](Ohua-xoxocoyolin.md) triturada en agua caliente, y el jugo debe administrarse como enema. Si este remedio no funciona, será necesario tomar la médula de una palma extremadamente delgada, cubierta con algodón fino y untada con miel y la raíz molida de la hierba [huihuitz-mallotic](Huihuitz-mallotic.md), e introducirla cuidadosamente en el miembro viril. Si se hace esto, se liberará la orina retenida.  

