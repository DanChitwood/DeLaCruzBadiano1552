
**Morphemes:**

- Atl/water

![N_ID020_p050_01_A-yecotli.png](assets/N_ID020_p050_01_A-yecotli.png)  
Leaf traces by: Noé García, UNAM ENES León, México  
