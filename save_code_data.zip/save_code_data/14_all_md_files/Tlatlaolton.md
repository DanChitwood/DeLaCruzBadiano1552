## Subchapter 7b  

=== "English :flag_us:"
    **For pain in the chest.** Pain in the chest is relieved by the plants [tetlahuitl](Tetlahuitl v1.md) and [teo-iztaquilitl](Teo-iztaquilitl.md) growing on a rock, together with the stone [tlacahuatzin](tlacal-huatzin.md), and red and white earth triturated in water; the skin of a lion is also to be burned and its broth drunk; the chest is to be rubbed with the juice expressed from the herb [tzitzicton](Tzitzicton.md), [tlatlaolton](Tlatlaolton.md), [ayauhtli](Ayauhtli.md), cypress seeds or nuts, and the [itzcuinpatli](Itzquin-patli.md) with the [huacal-xochitl](Huacal-xochitl.md) and [papalo-quilitl](Papalo-quilitl.md).  
    [https://archive.org/details/aztec-herbal-of-1552/page/46](https://archive.org/details/aztec-herbal-of-1552/page/46)  


=== "Español :flag_mx:"
    **Para dolor en el pecho.** El dolor en el pecho se alivia con las plantas [tetlahuitl](Tetlahuitl v1.md) y [teo-iztaquilitl](Teo-iztaquilitl.md) que crecen sobre la roca, junto con la piedra [tlacahuatzin](tlacal-huatzin.md), tierra roja y blanca trituradas en agua; también se debe quemar la piel de león y beber su caldo; se debe frotar el pecho con el jugo exprimido de la hierba [tzitzicton](Tzitzicton.md), [tlatlaolton](Tlatlaolton.md), [ayauhtli](Ayauhtli.md), semillas de ciprés o nueces, y el [itzcuinpatli](Itzquin-patli.md) con el [huacal-xochitl](Huacal-xochitl.md) y el [papalo-quilitl](Papalo-quilitl.md).  

## Subchapter 8k  

=== "English :flag_us:"
    **Against lassitude.** One fatigued will be restored if the feet be bathed in choice liquor, with the [ahuiyac-xihuitl](Ahuiyac-xihuitl.md) or [tlatlanquaye](Tlatlanquaye.md), [tlatlaolton](Tlatlaolton.md), [itzcuin-patli](Itzquin-patli.md), [xiuh-ecapatli](Eca-patli.md), [iztauh-yatl](Iztauyattl.md), the [huitzihtzil-xochitl](Huitzihtzil-xochitl.md) flower, and the stones [tetlahuitl](tetlahuitl v2.md), [tlaca-huatzin](tlacal-huatzin.md) and [eztetl](eztetl.md), to be crushed in hot water.  
    [https://archive.org/details/aztec-herbal-of-1552/page/66](https://archive.org/details/aztec-herbal-of-1552/page/66)  


=== "Español :flag_mx:"
    **Contra el cansancio.** Uno fatigado se restaurará si se le bañan los pies en un licor escogido, con [ahuiyac-xihuitl](Ahuiyac-xihuitl.md) o [tlatlanquaye](Tlatlanquaye.md), [tlatlaolton](Tlatlaolton.md), [itzcuin-patli](Itzquin-patli.md), [xiuh-ecapatli](Eca-patli.md), [iztauh-yatl](Iztauyattl.md), la flor [huitzihtzil-xochitl](Huitzihtzil-xochitl.md) y las piedras [tetlahuitl](tetlahuitl v2.md), [tlaca-huatzin](tlacal-huatzin.md) y [eztetl](eztetl.md), todo triturado en agua caliente.  

