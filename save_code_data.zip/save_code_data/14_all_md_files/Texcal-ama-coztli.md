
**Morphemes:**

- Amatl/paper
- Texcal/stone or cliff

![M_ID174_p068_03_Texcal-ama-coztli.png](assets/M_ID174_p068_03_Texcal-ama-coztli.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
