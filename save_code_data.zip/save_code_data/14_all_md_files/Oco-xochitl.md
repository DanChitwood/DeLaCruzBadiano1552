
**Morphemes:**

- Ocotl/pine
- Xochitl/flower

## Subchapter 2b  

=== "English :flag_us:"
    **Overheated eyes.** Into eyes much heated from sickness the ground root of this bush is instilled; let the face be further wiped with the squeezed juice of the bushes [oco-xochitl](Oco-xochitl.md), [huacal-xochitl](Huacal-xochitl.md), [matlal-xochitl](Matlal-xochitl.md) and [tlaco-izqui-xochitl](Tlaco-izqui-xochitl.md). Slightly troubled eyes are helped by the leaves of the [mizquitl](Mizquitl.md) tree and of the xoxouhqui [matlal-xochitl](Matlal-xochitl.md), macerated in woman’s milk, or dew, or limpid water, and instilled. One suffering from a defect of the eyes should abstain from sexual acts, the heat of the sun, smoke and wind, not use [chilmolli](chilmolli.md) as a sauce in his food, not eat hot foods. On his neck he must carry a red crystal, and not look at white things but black. The eye of a fox will help vitiated eyes wonderfully, being bound on the upper arm. If the eyes are so hurt that they look pulled out, pearls, reddish crystal, red mussels, the stone found in the small bird called [molo-tototl](molo-tototl.md), the stone [tlacal-huatzin](tlacal-huatzin.md), and the stone in the stomach of the Indian dove, ground up in goose’s grease, woman’s milk and spring water, should be taken; the juice thus prepared you shall instill into the effused eyes. When then something falls into the eyes, so that they fester from it, there should be instilled liquor prepared from ground siliqua or pulse, salt and flour, in spring water. If however the trouble comes from chill, it will be corrected if reddish crystal be ground in Indian wine and the liquor dropped in the eyes.  
    [https://archive.org/details/aztec-herbal-of-1552/page/14](https://archive.org/details/aztec-herbal-of-1552/page/14)  


=== "Español :flag_mx:"
    **Ojos sobrecalentados.**  En ojos muy calentados por enfermedad se instila la raíz molida de este arbusto; además, se limpia el rostro con el jugo exprimido de los arbustos [oco-xochitl](Oco-xochitl.md), [huacal-xochitl](Huacal-xochitl.md), [matlal-xochitl](Matlal-xochitl.md) y [tlaco-izqui-xochitl](Tlaco-izqui-xochitl.md). Los ojos levemente afectados se alivian con hojas del árbol [mizquitl](Mizquitl.md) y de la xoxouhqui [matlal-xochitl](Matlal-xochitl.md), maceradas en leche de mujer, o rocío, o agua clara, e instiladas. Quien padezca un defecto en los ojos debe abstenerse de actos sexuales, del calor del sol, del humo y del viento, no debe usar [chilmolli](chilmolli.md) como salsa en sus alimentos ni comer comidas calientes. Debe llevar un cristal rojo en el cuello y no mirar cosas blancas, sino negras. El ojo de un zorro ayudará de forma maravillosa a los ojos dañados, si se ata al brazo superior. Si los ojos están tan afectados que parecen salidos de su lugar, se deben moler perlas, cristal rojizo, mejillones rojos, la piedra hallada en el pájaro pequeño llamado [molo-tototl](molo-tototl.md), la piedra [tlacal-huatzin](tlacal-huatzin.md), y la piedra del estómago de la paloma indígena, todo con grasa de ganso, leche de mujer y agua de manantial; el jugo así preparado se debe instilar en los ojos desbordados. Cuando algo cae en los ojos y provoca supuración, se debe instilar un líquido preparado con siliqua o legumbre molida, sal y harina en agua de manantial. Si el problema proviene del frío, se corregirá si se muele cristal rojizo en vino indígena y el líquido se deja caer en los ojos.  

## Subchapter 10f  

=== "English :flag_us:"
    **Goaty armpits of sick people.** This evil smell is removed by anointing the body with the liquor of the herbs [ayauh-tonan-yxiuh](Ayauh-tonan-yxiuh.md), [papalo-quilitl](Papalo-quilitl.md), [xiuh-ecapatli](Eca-patli.md), the leaves being macerated in water; also the leaves of the pine and the flowers [oco-xochitl](Oco-xochitl.md), [tonaca-xochitl](Tonaca-xochitl.md), [totoloctzin](Totoloctzin.md) and sharp stones.  
    [https://archive.org/details/aztec-herbal-of-1552/page/99](https://archive.org/details/aztec-herbal-of-1552/page/99)  


=== "Español :flag_mx:"
    **Axilas de cabra de los enfermos.** Este mal olor se elimina ungiendo el cuerpo con el licor de las hierbas [ayauh-tonan-yxiuh](Ayauh-tonan-yxiuh.md), [papalo-quilitl](Papalo-quilitl.md), [xiuh-ecapatli](Eca-patli.md), maceradas en agua; también con hojas de pino y las flores [oco-xochitl](Oco-xochitl.md), [tonaca-xochitl](Tonaca-xochitl.md), [totoloctzin](Totoloctzin.md) y piedras puntiagudas.  

