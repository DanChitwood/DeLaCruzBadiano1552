
**Morphemes:**

- Huitzihtzil/colibri
- Quahuitl/tree or wood
- Xochitl/flower

![K_ID137_p069_07_Quauh-huitzihtzil-xochitl.png](assets/K_ID137_p069_07_Quauh-huitzihtzil-xochitl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
