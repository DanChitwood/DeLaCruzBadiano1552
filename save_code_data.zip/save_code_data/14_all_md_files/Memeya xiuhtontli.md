
**Morphemes:**

- Xihuitl/herbs, green leaves

![A_ID114_p111_02_Memeya_xiuhtontli.png](assets/A_ID114_p111_02_Memeya_xiuhtontli.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
