
**Morphemes:**

- Te/stone
- Xochitl/flower

![M_ID053_p064_01_Te-xochitl_yamanqui.png](assets/M_ID053_p064_01_Te-xochitl_yamanqui.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
