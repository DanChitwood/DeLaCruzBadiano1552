
**Morphemes:**

- Patli/medicine
- Tzon/hair

## Subchapter 6h  

=== "English :flag_us:"
    **For dropsy.** The water under the skin is to come out by cutting, and all purulence cleared out; this done, the leaves of bramble bushes and the [tzonpilihuiz-patli](Tzonpilihuiz-patli.md) are macerated and boiled in water with white frankincense, adding Indian wine. The medicine thus prepared is to be forthwith injected into the putrescent part, which is then covered up.  
    [https://archive.org/details/aztec-herbal-of-1552/page/42](https://archive.org/details/aztec-herbal-of-1552/page/42)  


=== "Español :flag_mx:"
    **Para la hidropesía.** El agua bajo la piel debe salir mediante corte, y toda la pus debe ser limpiada; hecho esto, se maceran y hierven en agua hojas de zarzamora y el [tzonpilihuiz-patli](Tzonpilihuiz-patli.md), añadiendo vino indígena. La medicina así preparada debe inyectarse de inmediato en la parte putrefacta, que luego se cubre.  

