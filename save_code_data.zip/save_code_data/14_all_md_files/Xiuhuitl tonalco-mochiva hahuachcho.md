
**Morphemes:**

- Tonalco/sun or heat
- Xihuitl/herbs, green leaves

![D_ID184_p012_01_Xiuhuitl_tonalco-mochiva_hahuachcho.png](assets/D_ID184_p012_01_Xiuhuitl_tonalco-mochiva_hahuachcho.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  
