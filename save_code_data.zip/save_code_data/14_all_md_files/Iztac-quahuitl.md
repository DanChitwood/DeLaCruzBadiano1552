
**Morphemes:**

- Iztac/white
- Quahuitl/tree or wood

![M_ID040_p068_05_Iztac-quahuitl.png](assets/M_ID040_p068_05_Iztac-quahuitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
