
**Morphemes:**

- Patli/medicine

## Subchapter 7n  

=== "English :flag_us:"
    **Ventral purgation.** When ventral pus forms, you will expel it if before meals the patient drinks a potion, in hot water, of the ground root of the plant called [huelic-patli](Huelic-patli.md); the patient’s bed, or where he lies, is to be impregnated with the odor of frankincense, whereby the noxious air is driven away.  
    [https://archive.org/details/aztec-herbal-of-1552/page/55](https://archive.org/details/aztec-herbal-of-1552/page/55)  


=== "Español :flag_mx:"
    **Purgación ventral.** Cuando se forma pus ventral, se expulsará si, antes de las comidas, el paciente bebe una poción, en agua caliente, hecha con la raíz molida de la planta llamada [huelic-patli](Huelic-patli.md); el lecho del paciente, o donde yace, debe impregnarse con el olor del copal, con lo cual se ahuyenta el aire nocivo.  

