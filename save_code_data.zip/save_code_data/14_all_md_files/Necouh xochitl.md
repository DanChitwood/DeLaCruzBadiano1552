
**Morphemes:**

- Xochitl/flower

![Z_ID120_p097_02_Necouh_xochitl.png](assets/Z_ID120_p097_02_Necouh_xochitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
