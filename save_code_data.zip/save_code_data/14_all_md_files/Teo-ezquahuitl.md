
**Morphemes:**

- Teo/divine

![M_ID035_p068_06_Teo-ezquahuitl.png](assets/M_ID035_p068_06_Teo-ezquahuitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
