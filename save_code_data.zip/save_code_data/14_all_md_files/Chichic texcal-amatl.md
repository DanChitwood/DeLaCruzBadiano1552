
**Morphemes:**

- Amatl/paper
- Chichic/bitter
- Texcal/stone or cliff

![K_ID089_p078_01_Chichic_texcal-amatl.png](assets/K_ID089_p078_01_Chichic_texcal-amatl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
