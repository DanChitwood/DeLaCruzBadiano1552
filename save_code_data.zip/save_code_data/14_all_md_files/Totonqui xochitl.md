
**Morphemes:**

- Xochitl/flower

![M_ID186_p067_01_Totonqui_xochitl.png](assets/M_ID186_p067_01_Totonqui_xochitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
![M_ID186_p067_07_Totonqui_xochitl.png](assets/M_ID186_p067_07_Totonqui_xochitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
