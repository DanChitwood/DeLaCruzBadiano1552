
**Morphemes:**

- Mecatl/cord, rope, or vine

## Subchapter 9c  

=== "English :flag_us:"
    **Haemorrhoids.** Against haemorrhoids the root of the herb [colo-mecatl](Colo-mecatl.md) helps greatly, since it draws away the bile if it be drunk in hot water, crushed up with honey. Second, the plant [teo-amatl](Teo-amatl.md) that grows on the rocks must have the skin removed that the abundant milky juice may flow. Received then on cotton and put in the sun for a little while, it is to be drunk in moderation that the pale bile be drawn out. Then let a medicine be prepared from the skins of the plants [quauh-izqui-xochitl](Quauh-izqui-xochitl.md) and . . . . . . with salt, and ground in hot water; this will also draw the purulence from the abdomen and clear the intestines of the man. Before a meal let him kill a weasel and eat it quite alone with dragon’s blood.  
    [https://archive.org/details/aztec-herbal-of-1552/page/77](https://archive.org/details/aztec-herbal-of-1552/page/77)  


=== "Español :flag_mx:"
    **Hemorragias anales.** Contra las hemorroides ayuda mucho la raíz de la hierba [colo-mecatl](Colo-mecatl.md), ya que extrae la bilis si se bebe en agua caliente, triturada con miel. En segundo lugar, la planta [teo-amatl](Teo-amatl.md) que crece en las rocas debe pelarse para que fluya su jugo lechoso. Este jugo, recogido en algodón y dejado un poco al sol, debe beberse con moderación para expulsar la bilis pálida. Luego debe prepararse un medicamento con las cáscaras de las plantas [quauh-izqui-xochitl](Quauh-izqui-xochitl.md) y . . . . . . con sal, molidas en agua caliente; esto también extraerá el pus del abdomen y limpiará los intestinos del hombre. Antes de comer, debe matar una comadreja y comerla completamente solo con sangre de dragón.  

![K_ID079_p077_01_Colo-mecatl.png](assets/K_ID079_p077_01_Colo-mecatl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
