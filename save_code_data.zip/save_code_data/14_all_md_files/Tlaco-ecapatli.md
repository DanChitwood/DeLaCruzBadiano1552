**Variants:**

- tlaco-eca-patli


**Morphemes:**

- Ecatl/wind
- Tlaco/half or middle


## Subchapter 9l  

=== "English :flag_us:"
    **Swelling of the veins after phlebotomy.** When a vein comes to swelling after being cut, the bushes[tzihuac-copalli](Tzihuac-copalli.md) and [tlaco-eca-patli](Tlaco-ecapatli.md), [tetzmitl](Tetzmitl.md), the root of the plant [tlanen-popoloa](Tla-nen-popoloua.md), the leaves of the herb [quauh-yyauhtli](Quauh-yyauhtli.md) andahuiyac tlatlanquaye, with the herb [coyo-xihuitl](Coyo-xihuitl.md) are ground together with yolk of egg, in which water breathing the odor of frankincense is then poured, and the incised vein soaked with this liquor.  
    [https://archive.org/details/aztec-herbal-of-1552/page/86](https://archive.org/details/aztec-herbal-of-1552/page/86)  


=== "Español :flag_mx:"
    **Hinchazón de las venas después de la flebotomía.** Cuando una vena se hincha después de ser cortada, los arbustos [tzihuac-copalli](Tzihuac-copalli.md) y [tlaco-eca-patli](Tlaco-ecapatli.md), [tetzmitl](Tetzmitl.md), la raíz de la planta [tlanen-popoloa](Tla-nen-popoloua.md), las hojas de la hierba [quauh-yyauhtli](Quauh-yyauhtli.md) y ahuiyac tlatlanquaye, junto con la hierba [coyo-xihuitl](Coyo-xihuitl.md), se muelen con yema de huevo, en la cual se vierte agua con olor a copal. Luego se empapa la vena cortada con este licor.  

