
**Morphemes:**

- Cococ/hot or spicy

## Subchapter 6b  

=== "English :flag_us:"
    **For a cough.** If one is troubled by a cough, let him forthwith sip the boiled liquor of the [tlaco-xilo-xochitl](Tlaco-xilo-xochitl.md) root skinned and ground up in water; using a part of this, with honey, to anoint the throat. If he spits blood also, let him take the same liquor as a drink before meals. It would help if he gnawed and chewed some of the said root, with honey. The root of the herb called [tzopelica-cococ](Tzopelica-cococ.md), ground in tepid water is also of value for one with a cough; let him either drink the liquor or gnaw the root.  
    [https://archive.org/details/aztec-herbal-of-1552/page/37](https://archive.org/details/aztec-herbal-of-1552/page/37)  


=== "Español :flag_mx:"
    **Para la tos.** Si alguien sufre de tos, que beba de inmediato el licor hervido de la raíz del [tlaco-xilo-xochitl](Tlaco-xilo-xochitl.md) pelada y molida en agua; parte de este licor, mezclado con miel, se usa para untar la garganta. Si también escupe sangre, que beba el mismo licor antes de las comidas. También ayuda masticar y morder algo de dicha raíz con miel. La raíz de la hierba llamada [tzopelica-cococ](Tzopelica-cococ.md), molida en agua tibia, también es útil para quien tiene tos; que beba el licor o muerda la raíz.  

