
**Morphemes:**

- Quahuitl/tree or wood
- Xocotl/sour fruit

![K_ID262_p069_04_Xococ_quahuitl.png](assets/K_ID262_p069_04_Xococ_quahuitl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
