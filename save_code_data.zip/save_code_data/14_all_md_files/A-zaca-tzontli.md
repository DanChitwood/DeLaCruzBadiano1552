
**Morphemes:**

- Atl/water
- Tzon/hair
- Zacatl/grass

![K_ID026_p079_02_A-zaca-tzontli.png](assets/K_ID026_p079_02_A-zaca-tzontli.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
