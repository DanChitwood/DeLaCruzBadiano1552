## Subchapter 6f  

=== "English :flag_us:"
    **For scrofulous tumors.** One scrofulous is relieved of the ailment if a plaster is applied to the neck, made of plants growing in a burned over thicket of bushes or reeds, the [tolova-xihuitl](Tolohua xihuitl.md), the [tonatiuh yxiuh](Tonatiuh yxiuh v1.md), the root of the [tecpatl](Tecpatl.md), and the leaves of bramble bushes; crush these with the stone found in a swallow’s stomach, with his blood.  
    [https://archive.org/details/aztec-herbal-of-1552/page/41](https://archive.org/details/aztec-herbal-of-1552/page/41)  


=== "Español :flag_mx:"
    **Para tumores escrofulosos.** El escrofuloso se alivia de la dolencia si se aplica un emplasto en el cuello, hecho con plantas que crecen en un matorral o cañaveral quemado, el [tolova-xihuitl](Tolohua xihuitl.md), el [tonatiuh yxiuh](Tonatiuh yxiuh v1.md), la raíz del [tecpatl](Tecpatl.md) y las hojas de zarzamora; se trituran con la piedra que se encuentra en el estómago de una golondrina, junto con su sangre.  

