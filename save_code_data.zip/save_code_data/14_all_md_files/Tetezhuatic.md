**Variants:**

- te-tezhuatic

## Subchapter 6e  

=== "English :flag_us:"
    **For mouth sores.** Scabs on the lips will be completely removed by a medicament made up of the [tlal-mizquitl](Tlal-mizquitl.md) root, whose viscous drops or tears are condensed to the thickness of gum, the leaves of the [eca-patli](Eca-patli.md), nettle seeds, and pounded up leaves of the [te-tezhuatic](Tetezhuatic.md).  
    [https://archive.org/details/aztec-herbal-of-1552/page/40](https://archive.org/details/aztec-herbal-of-1552/page/40)  


=== "Español :flag_mx:"
    **Para llagas en la boca.** Las costras en los labios se eliminarán completamente con un medicamento hecho de la raíz del [tlal-mizquitl](Tlal-mizquitl.md), cuyas gotas viscosas o lágrimas se condensan hasta tener el grosor de la goma, las hojas del [eca-patli](Eca-patli.md), semillas de ortiga y hojas machacadas del [te-tezhuatic](Tetezhuatic.md).  

