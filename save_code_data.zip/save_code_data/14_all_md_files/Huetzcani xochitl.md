
**Morphemes:**

- Xochitl/flower

![M_ID098_p067_11_Huetzcani_xochitl.png](assets/M_ID098_p067_11_Huetzcani_xochitl.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
