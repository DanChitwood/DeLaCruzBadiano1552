
**Morphemes:**

- Quahuitl/tree or wood

## Subchapter 9q  

=== "English :flag_us:"
    **Those struck by lightning.** Let one struck by a thunderbolt drink a potion well prepared from leaves of trees, namely the [ayauh-quahuitl](Ayauh-quahuitl.md), [tepaquilti quahuitl](tepaquilti quahuitl.md), very green cypress, the bush [iztauh-yatl](Iztauyattl.md), the herbs [quauh-yyauhtli](Quauh-yyauhtli.md) and [te-amoxtli](Te-amoxtli.md). But however the drink is to be given, let it be heated.  Let the body also be anointed with a plaster made of the herbs [papalo-quilitl](Papalo-quilitl.md), [tlal-ecapatli](Tlal-ecapatli.md), [quauh-yyauhtli](Quauh-yyauhtli.md), [tlatlanquaye](Tlatlanquaye.md), huitbitzil xochitil, [iztac-oco-xochitl](Iztac oco-xochitl.md), and in addition all the plants upon which the lightning struck. A few days later lethim drink water into which white frankincense is thrown. The water is boiled with white and whitish incense, with the burned bones of a fox added. Also mix some Indian wine with the above. Afterwards you will instill into the nostrils a medicine made of white pearl, the root [tlatlacotic](Tlatlacotic.md), and all plants growing in a garden that has been burned over. Let also be suffumigated by white incense thrown upon the coals, the wax ointment we call [xochi-oco-tzotl](xochi-ocotzotl.md), and the good odor of the herb [quauh-yyauhtli](Quauh-yyauhtli.md).  
    [https://archive.org/details/aztec-herbal-of-1552/page/91](https://archive.org/details/aztec-herbal-of-1552/page/91)  


=== "Español :flag_mx:"
    **Golpeados por un rayo.** Quien haya sido golpeado por un rayo debe beber una poción bien preparada con hojas de árboles, a saber: [ayauh-quahuitl](Ayauh-quahuitl.md), [tepaquilti quahuitl](tepaquilti quahuitl.md), ciprés muy verde, el arbusto [iztauh-yatl](Iztauyattl.md), las hierbas [quauh-yyauhtli](Quauh-yyauhtli.md) y [te-amoxtli](Te-amoxtli.md). Pero sea como sea que se le dé a beber, debe calentarse. También se unta el cuerpo con un emplasto hecho de las hierbas [papalo-quilitl](Papalo-quilitl.md), [tlal-ecapatli](Tlal-ecapatli.md), [quauh-yyauhtli](Quauh-yyauhtli.md), [tlatlanquaye](Tlatlanquaye.md), huitbitzil xochitil, [iztac-oco-xochitl](Iztac oco-xochitl.md), y además todas las plantas sobre las que cayó el rayo. Unos días después debe beber agua en la que se ha arrojado copal blanco. El agua se hierve con incienso blanco y blanquecino, con huesos quemados de zorro añadidos. También se mezcla algo de vino indígena con lo anterior. Después se le instila en las narices un medicamento hecho de perla blanca, la raíz [tlatlacotic](Tlatlacotic.md), y todas las plantas que crecen en un jardín quemado. También debe ser sahumado con copal blanco sobre las brasas, el ungüento de cera que llamamos [xochi-oco-tzotl](xochi-ocotzotl.md), y el buen aroma de la hierba [quauh-yyauhtli](Quauh-yyauhtli.md).  

