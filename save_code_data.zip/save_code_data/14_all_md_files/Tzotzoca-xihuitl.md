
**Morphemes:**

- Xihuitl/herbs, green leaves

![Z_ID238_p096_01_Tzotzoca-xihuitl.png](assets/Z_ID238_p096_01_Tzotzoca-xihuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
