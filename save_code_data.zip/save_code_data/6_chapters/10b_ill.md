
=== "English :flag_us:"
    **The cure for one harassed by a tornado or evil wind.** One who has been caught in a tornado, let him drink the healthful liquor of the plant [quauh-yayahual](Quauh-yayahual.md), the [acxoyatl](Acxoyatl.md), with pine and laurel leaves crushed in water. The broth should be boiled and drunk thus. Drunk it expels the evil air entering within. Second; take the liquor of these stones, the red crystal, white pearl, white earth, ground up in water, with the leaves of the plant tlatlanquaye, boiling this with incense. Anoint him with cypress and cedar nuts, and the leaves of the plant [qauh-yyauhtli](Quauh-yyauhtli.md), and those of the plant [xiuh-ecapatli](Eca-patli.md), all ground in water with incense and the liquor carefully prepared.  
    [https://archive.org/details/aztec-herbal-of-1552/page/95](https://archive.org/details/aztec-herbal-of-1552/page/95)  


=== "Español :flag_mx:"
    **Remedio para quien ha sido hostigado por un torbellino o viento maligno.** A quien ha sido atrapado por un torbellino, que beba el licor saludable de la planta [quauh-yayahual](Quauh-yayahual.md), el [acxoyatl](Acxoyatl.md), con hojas de pino y laurel machacadas en agua. El cocimiento debe hervirse y beberse así. Al beberlo expulsa el aire maligno que ha entrado. En segundo lugar: tomar el licor de estas piedras, el cristal rojo, perla blanca y tierra blanca, molidas en agua con las hojas de la planta tlatlanquaye, hirviendo todo esto con incienso. Se le debe untar con nueces de ciprés y cedro, y con hojas de la planta [qauh-yyauhtli](Quauh-yyauhtli.md), y de la planta [xiuh-ecapatli](Eca-patli.md), todas molidas en agua con incienso y el licor cuidadosamente preparado.  


![Z_p095.png](assets/Z_p095.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  