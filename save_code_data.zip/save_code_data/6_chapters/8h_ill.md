
=== "English :flag_us:"
    **Incipient contraction of the knees.** When the knees start to contract, anoint them with the juice of the plants [xiuhtontli](Xiuhtontli.md) or [tzitzicton](Tzitzicton.md), yamanqui te-xochitl, crushed in hawk’s blood and that of a bird called [huacton](huacton.md). Let the patient also enter the bath, and eat the cooked feet of the hawk, the huachtli, rabbit and hare. After that let the flesh of a very combative cock be boiled, which he shall eat, with some of it crushed as an ointment with goose grease. Let him abstain from sex converse, not avoid sleep, sleep sitting or supine, labor much, and not overheat.  
    [https://archive.org/details/aztec-herbal-of-1552/page/64](https://archive.org/details/aztec-herbal-of-1552/page/64)  


=== "Español :flag_mx:"
    **Contracción incipiente de las rodillas.** Cuando las rodillas comienzan a contraerse, úntalas con el jugo de las plantas [xiuhtontli](Xiuhtontli.md) o [tzitzicton](Tzitzicton.md), yamanqui te-xochitl, trituradas en sangre de halcón y de un ave llamada [huacton](huacton.md). El paciente también debe bañarse y comer los pies cocidos del halcón, el huachtli, conejo y liebre. Después, debe hervirse la carne de un gallo muy combativo, que él deberá comer, y parte de ella se machaca como ungüento con grasa de ganso. Que se abstenga del trato sexual, que no evite dormir, que duerma sentado o acostado boca arriba, que trabaje mucho y que no se sobrecaliente.  


![M_p064.png](assets/M_p064.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  