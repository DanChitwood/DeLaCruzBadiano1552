
=== "English :flag_us:"
    **Against lassitude.** One fatigued will be restored if the feet be bathed in choice liquor, with the [ahuiyac-xihuitl](Ahuiyac-xihuitl.md) or [tlatlanquaye](Tlatlanquaye.md), [tlatlaolton](Tlatlaolton.md), [itzcuin-patli](Itzquin-patli.md), [xiuh-ecapatli](Eca-patli.md), [iztauh-yatl](Iztauyattl.md), the [huitzihtzil-xochitl](Huitzihtzil-xochitl.md) flower, and the stones [tetlahuitl](tetlahuitl v2.md), [tlaca-huatzin](tlacal-huatzin.md) and [eztetl](eztetl.md), to be crushed in hot water.  
    [https://archive.org/details/aztec-herbal-of-1552/page/66](https://archive.org/details/aztec-herbal-of-1552/page/66)  


=== "Español :flag_mx:"
    **Contra el cansancio.** Uno fatigado se restaurará si se le bañan los pies en un licor escogido, con [ahuiyac-xihuitl](Ahuiyac-xihuitl.md) o [tlatlanquaye](Tlatlanquaye.md), [tlatlaolton](Tlatlaolton.md), [itzcuin-patli](Itzquin-patli.md), [xiuh-ecapatli](Eca-patli.md), [iztauh-yatl](Iztauyattl.md), la flor [huitzihtzil-xochitl](Huitzihtzil-xochitl.md) y las piedras [tetlahuitl](tetlahuitl v2.md), [tlaca-huatzin](tlacal-huatzin.md) y [eztetl](eztetl.md), todo triturado en agua caliente.  


![M_p066.png](assets/M_p066.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  