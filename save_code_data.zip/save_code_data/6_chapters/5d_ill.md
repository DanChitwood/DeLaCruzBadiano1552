
=== "English :flag_us:"
    **Overheated throat or pharynx.** The leaves of the [te-amoxtli](Te-amoxtli.md), the [tlanexti](Tlanextia xiuhtontli.md), with the root ofthe osiers called [tol-patlactli](Tol-patlactli.md), crushed in water, cool heat in the throat. With this is mixed the liquor of ground gold bronze or pyropus, and the stone [ez-tetl](eztetl.md), and then hold as much of this as can be, in the mouth inside the teeth, not passing it into the stomach.  
    [https://archive.org/details/aztec-herbal-of-1552/page/29](https://archive.org/details/aztec-herbal-of-1552/page/29)  


=== "Español :flag_mx:"
    **Garganta o faringe recalentada.** Las hojas del [te-amoxtli](Te-amoxtli.md), del [tlanexti](Tlanextia xiuhtontli.md), junto con la raíz de los sauces llamados [tol-patlactli](Tol-patlactli.md), trituradas en agua, enfrían el calor en la garganta. A esto se le añade el licor de bronce dorado molido o piropo, y la piedra [ez-tetl](eztetl.md); luego se sostiene todo cuanto se pueda dentro de la boca, entre los dientes, sin tragarlo.  


![D_p029.png](assets/D_p029.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  