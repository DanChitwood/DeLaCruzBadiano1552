
=== "English :flag_us:"
    **Affections of the rectum.** Rectal affection is cured by the herbs [iztauh-yatl](Iztauyattl.md), [tonatiuh-yxiuh](Tonatiuh yxiuh v1.md), coyo-xihuitl tlaztalehualtic, [iztac-oco-xochitl](Iztac oco-xochitl.md), and the leaves of the herb [tepe-chian](Tepe-chian.md) ground together in hot water, with which remedy the part suffering pain is to be bathed; or they may also be poulticed, brought to mud thickness.  
    [https://archive.org/details/aztec-herbal-of-1552/page/61](https://archive.org/details/aztec-herbal-of-1552/page/61)  


=== "Español :flag_mx:"
    **Afecciones del recto.** Las afecciones rectales se curan con las hierbas [iztauh-yatl](Iztauyattl.md), [tonatiuh-yxiuh](Tonatiuh yxiuh v1.md), coyo-xihuitl tlaztalehualtic, [iztac-oco-xochitl](Iztac oco-xochitl.md), y las hojas de la hierba [tepe-chian](Tepe-chian.md) molidas en agua caliente, con este remedio se baña la parte dolorida; también puede aplicarse como cataplasma, llevándola al grosor de lodo.  


![M_p061.png](assets/M_p061.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  