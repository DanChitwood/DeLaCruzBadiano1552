
=== "English :flag_us:"
    **Pain in the knees.** When the knees pain one, anoint them with the liquor of the plants [coyo-xihuitl](Coyo-xihuitl.md), [tepe-chian](Tepe-chian.md), [xoxouhca-patli](xoxouhca-patli.md) macerated with the [te-amoxtli](Te-amoxtli.md) in swallow's blood.  
    [https://archive.org/details/aztec-herbal-of-1552/page/63](https://archive.org/details/aztec-herbal-of-1552/page/63)  


=== "Español :flag_mx:"
    **Dolor en las rodillas.** Cuando duelen las rodillas, se deben untar con el licor de las plantas [coyo-xihuitl](Coyo-xihuitl.md), [tepe-chian](Tepe-chian.md), [xoxouhca-patli](xoxouhca-patli.md) maceradas con el [te-amoxtli](Te-amoxtli.md) en sangre de golondrina.  


![M_p063.png](assets/M_p063.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  