
=== "English :flag_us:"
    **Cataract.** A carbuncle growing in the eye should be lanced, then drawn and extracted; the film should be sprinkled little by little with the ashes from human ordure with salt. Then on the following day the roots of our acid plants, first placed in the sun, should be pounded up and applied.  
    [https://archive.org/details/aztec-herbal-of-1552/page/17](https://archive.org/details/aztec-herbal-of-1552/page/17)  


=== "Español :flag_mx:"
    **Cataratas.** Un carbunclo que crece en el ojo debe ser abierto, luego extraído y removido; la película debe ser espolvoreada poco a poco con cenizas de excremento humano y sal. Al día siguiente deben machacarse y aplicarse las raíces de nuestras plantas ácidas, previamente expuestas al sol.  


![D_p017.png](assets/D_p017.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  