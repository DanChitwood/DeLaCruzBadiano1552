
=== "English :flag_us:"
    **Medicine to ease pain in the throat.** The liquor of the small herbs [tlanexti](Tlanextia xiuhtontli.md) and [teo-iztac-quilitl](Teo-iztaquilitl.md), that grow in stony places, crushed in honey with red and white earth, reduces pain in the throat, if lightly rubbed on with a finger inserted into the mouth.  
    [https://archive.org/details/aztec-herbal-of-1552/page/31](https://archive.org/details/aztec-herbal-of-1552/page/31)  


=== "Español :flag_mx:"
    **Medicina para aliviar el dolor de garganta.** El licor de las pequeñas hierbas [tlanexti](Tlanextia xiuhtontli.md) y [teo-iztac-quilitl](Teo-iztaquilitl.md), que crecen en lugares pedregosos, trituradas con miel, tierra roja y blanca, alivia el dolor de garganta si se frota suavemente con un dedo introducido en la boca.  


![D_p031.png](assets/D_p031.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  