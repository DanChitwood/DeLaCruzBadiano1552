**Medicine to bring the saliva when dry.** The saliva will flow and excessive thirst repressed if the acid herbs of the woodland, alectoria or the gems found in the maw of cocks, as also stated by Pliny, of crystalline appearance and the size of an Indian or Spanish bean, an Indian kite, a slain dove, are ground in clear water. Let one lacking saliva and immoderately thirsty swallow some of the liquor and hold as much as the mouth will contain. Also let the liquor of herbs macerated, the [tetzmi-nopalli]('Tetzmi-nopalli.md')to wit, and the tepe chian, be poured over the head; to avoid an error use the leaves only, not the plant itself.    
[https://archive.org/details/aztec-herbal-of-1552/page/32](https://archive.org/details/aztec-herbal-of-1552/page/32)  


![D_p032.png](assets/D_p032.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  