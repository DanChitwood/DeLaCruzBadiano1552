**For warts.** One having these is cured if you apply the leaves of the verrucarium or wart-wort, macerated in water, to the warts, whereby they rot away. The warts will also be driven away by frequently washing them with water in which a human corpse has been bathed.    
[https://archive.org/details/aztec-herbal-of-1552/page/96](https://archive.org/details/aztec-herbal-of-1552/page/96)  


![Z_p096.png](assets/Z_p096.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  