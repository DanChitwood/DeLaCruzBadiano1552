**For a broken head.** The break is to be smeared with plants growing in summer dew, with green-stone, pearls, crystal and the [tlacalhuatzin]('tlacal-huatzin.md'), and with wormy earth, ground up in the blood from a bruised vein and the white of egg; if the blood cannot be had, burned frogs will take the place.    
[https://archive.org/details/aztec-herbal-of-1552/page/12](https://archive.org/details/aztec-herbal-of-1552/page/12)  


![D_p012.png](assets/D_p012.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  