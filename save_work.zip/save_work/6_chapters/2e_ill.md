**Immobility of the eyelids.** When the lids are drawn with numbness, that is, when the upper does not drop and the lower raises but a little so as not to meet the upper, the leaves of the [malinalli]('Malinalli.md') rubbed on the lids are useful; after this nitre, salt and powdered ordure should be sprinkled on them.    
[https://archive.org/details/aztec-herbal-of-1552/page/18](https://archive.org/details/aztec-herbal-of-1552/page/18)  


![D_p018.png](assets/D_p018.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  