**Cataract.** A carbuncle growing in the eye should be lanced, then drawn and extracted; the film should be sprinkled little by little with the ashes from human ordure with salt. Then on the following day the roots of our acid plants, first placed in the sun, should be pounded up and applied.    
[https://archive.org/details/aztec-herbal-of-1552/page/17](https://archive.org/details/aztec-herbal-of-1552/page/17)  


![D_p017.png](assets/D_p017.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  