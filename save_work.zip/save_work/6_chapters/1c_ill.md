**Scales or mange.** A scaly head being diligently washed with heated lye, the juice of acid plants from the forests, well expressed and strained, is to be poured over the sores; when this has dried, the head scales are to be smeared with the gall of a dog, wolf, mole, hawk, swallow, the diver-bird, quail and [atzitzicuilotl]('atzitzicuilotl.md'), with the dregs or lees of the Indian wine. As a drink let the one affected take heated native wine, to be drunk in honey that is not heated. Before dinner let him be very careful not to sleep, and after dinner let him not walk about, neither walk nor run, nor work.    
[https://archive.org/details/aztec-herbal-of-1552/page/9](https://archive.org/details/aztec-herbal-of-1552/page/9)  


![D_p009.png](assets/D_p009.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  