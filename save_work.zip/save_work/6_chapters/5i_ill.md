**Medicine to take away foul and fetid breath.** The root and leaves of the plant called [tlatlanquaye]('Tlatlanquaye.md'), red earth, white earth, the plants [temamatlatzin]('Temamatlatzin.md') and [tlanextia xiuhtontli]('Tlanextia_xiuhtontli.md') ground and cooked in water with honey, suppress bad breath; the liquor, well strained, is further to be drunk before eating.    
[https://archive.org/details/aztec-herbal-of-1552/page/34](https://archive.org/details/aztec-herbal-of-1552/page/34)  


![D_p034.png](assets/D_p034.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  