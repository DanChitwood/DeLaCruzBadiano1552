**Against animalcula that descend into a man’s stomach.** When one swallows animalcula, crush Indian beans and place in his mouth; then let him enter a well heated bath. When he feels the heat thoroughly, let him sip bitter water, without taking it down. Then if God wills he will eliminate the animalculum through the mouth by vomiting, or through the abdomen behind; or it may die there, and then when it is ejected, let him drink [tlatlanquaye]('Tlatlanquaye.md')crushed in the finest Indian wine.    
[https://archive.org/details/aztec-herbal-of-1552/page/50](https://archive.org/details/aztec-herbal-of-1552/page/50)  


![N_p050.png](assets/N_p050.png)  
Leaf traces by: Noé García, UNAM ENES León, México  