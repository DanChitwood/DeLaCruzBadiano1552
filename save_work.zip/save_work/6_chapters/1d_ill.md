**Scurf or head-scald.** The head is to be washed with urine. Then the roots of the [huitz-quilitl]('Huitz-quilitl.md'), [tezon-patli]('Tezon-patli.md'), [tequam-maitl]('Tequam-maitl.md'), [tetzmi-xochitl]('Tetzmi-xochitl.md'), groundup with the bark of the [copal-quahuitl]('Copal-quahuitl.md') and [atoya-xocotl]('Atoya-xocotl.md'), are tobe applied to the head.    
[https://archive.org/details/aztec-herbal-of-1552/page/10](https://archive.org/details/aztec-herbal-of-1552/page/10)  


![D_p010.png](assets/D_p010.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  