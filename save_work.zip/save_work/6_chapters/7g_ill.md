**Medicine to kill worms.** Let the herbs [tzonpilihuiz-xihuitl]('Tzon-pilihuiz-xihuitl.md') and ahhuachcho tonatiuh-yxiuh be ground with frankincense and boiled. Let the broth well cooked be clarified and then drunk, which will get rid of the worms.    
[https://archive.org/details/aztec-herbal-of-1552/page/51](https://archive.org/details/aztec-herbal-of-1552/page/51)  


![N_p051.png](assets/N_p051.png)  
Leaf traces by: Noé García, UNAM ENES León, México  