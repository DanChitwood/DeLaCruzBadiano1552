**To increase the flow of milk.** Where the milk flows with difficulty, take the plants [chichiltic xiuhtontli]('Chichiltic_xiuhtontli.md'), which shows acid slightly, the tohmiyo xihuitland crystal, ground up in pulque and boiled. Let her drink it frequently. Afterwards macerate the plant memeya xiuhtontilin pulque and let her also drink that juice; let her enter the bath and there have another drink, made from corn. On leaving it, let her take the viscous water drawn from the grain.    
[https://archive.org/details/aztec-herbal-of-1552/page/111](https://archive.org/details/aztec-herbal-of-1552/page/111)  


![A_p111.png](assets/A_p111.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  