**Blood-stanching plants.** For nose-bleed the juice of nettles crushed as a lotion, with milk, infused into the nostrils will stop it.    
[https://archive.org/details/aztec-herbal-of-1552/page/26](https://archive.org/details/aztec-herbal-of-1552/page/26)  


![D_p026.png](assets/D_p026.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  