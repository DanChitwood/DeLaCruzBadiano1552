**Lost or broken sleep.** Lost sleep is attracted and conciliated by the plant [tlazol-patli]('Tlazol-patli.md'), which grows by ants’ nests; also the [cochiz-xihuitl]('Cochiz-xihuitl.md') ground up with swallow’s gall and applied to the forehead; also the liquor squeezed from the leaves of the [huihuitzyo-cochiz-xihuitl]('Huihuitzyo-cochiz-xihuitl.md'), should be used to anoint the body.    
[https://archive.org/details/aztec-herbal-of-1552/page/20](https://archive.org/details/aztec-herbal-of-1552/page/20)  


![D_p020.png](assets/D_p020.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  