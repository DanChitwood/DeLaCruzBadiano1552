Variants: tzonpilihuiz-xihuitl  

## Subchapter 4a  
**Catarrh.** One who has running at the nose or a cold will be helped by smelling the plants [a-toch-ietl]('A-toch-ietl.md') and [tzonpilihuiz-xihuitl]('Tzon-pilihuiz-xihuitl.md'), andthe catarrh thus cured.    
[https://archive.org/details/aztec-herbal-of-1552/page/24](https://archive.org/details/aztec-herbal-of-1552/page/24)  

## Subchapter 7g  
**Medicine to kill worms.** Let the herbs [tzonpilihuiz-xihuitl]('Tzon-pilihuiz-xihuitl.md') and ahhuachcho tonatiuh-yxiuh be ground with frankincense and boiled. Let the broth well cooked be clarified and then drunk, which will get rid of the worms.    
[https://archive.org/details/aztec-herbal-of-1552/page/51](https://archive.org/details/aztec-herbal-of-1552/page/51)  

![D_ID236_Tzon-pilihuiz-xihuitl.png](assets/D_ID236_Tzon-pilihuiz-xihuitl.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  
