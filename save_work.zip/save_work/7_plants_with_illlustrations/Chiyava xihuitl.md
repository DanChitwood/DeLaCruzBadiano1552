Variants: chiyava-xihuitl  

## Subchapter 10g  
**The goatlike smell of the armpits.** When smelly and goaty, let him enter a very well prepared bath, and there wash the armpits thoroughly; coming out let him also bathe; for this take the crushed plants[chiyava-xihuitl]('Chiyava_xihuitl.md'), a human and a dog’s bone recently removed from the body, and the juice of all well smelling flowers and plants, with which the hircine odor will be dispelled.    
[https://archive.org/details/aztec-herbal-of-1552/page/100](https://archive.org/details/aztec-herbal-of-1552/page/100)  

![A_ID093_Chiyava_xihuitl.png](assets/A_ID093_Chiyava_xihuitl.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
