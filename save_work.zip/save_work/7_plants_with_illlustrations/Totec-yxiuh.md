Variants  

![A_ID188_Totec-yxiuh.png](assets/A_ID188_Totec-yxiuh.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
