Variants  

![A_ID177_Tohmiyo-xihuitl.png](assets/A_ID177_Tohmiyo-xihuitl.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
