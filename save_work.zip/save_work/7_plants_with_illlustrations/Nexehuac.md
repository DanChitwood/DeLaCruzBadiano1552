Variants: nexehuac  

## Subchapter 7e  
**For pain in the side.** For a pain in the side apply the plants called [tolohua-xihuitl]('Tolohua_xihuitl.md')and [nexehuac]('Nexehuac.md').    
[https://archive.org/details/aztec-herbal-of-1552/page/49](https://archive.org/details/aztec-herbal-of-1552/page/49)  

![N_ID121_Nexehuac.png](assets/N_ID121_Nexehuac.png)  
Leaf traces by: Noé García, UNAM ENES León, México  
