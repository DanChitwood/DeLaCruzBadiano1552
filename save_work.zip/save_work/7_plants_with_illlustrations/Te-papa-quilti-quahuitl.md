Variants  

![K_ID158_Te-papa-quilti-quahuitl.png](assets/K_ID158_Te-papa-quilti-quahuitl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
