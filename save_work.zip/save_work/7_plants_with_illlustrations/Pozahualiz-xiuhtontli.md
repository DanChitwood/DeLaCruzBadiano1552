Variants: pozahualiz-xiuhtontli  

## Subchapter 11d  
**Breast tubercles.** For a tumor forming on the breast, take the ground up leaves and acorns of the cedar, leaves and root of the [quauh-yyauhtli]('Quauh-yyauhtli.md'), the plants [elo-zacatl]('Elo-zacatl.md'), reeds, [pozahualiz-xiuhtontli]('Pozahualiz-xiuhtontli.md') and totec yxiuh, and squeeze out the juice to rub on the swelling breasts.    
[https://archive.org/details/aztec-herbal-of-1552/page/110](https://archive.org/details/aztec-herbal-of-1552/page/110)  

![A_ID132_Pozahualiz-xiuhtontli.png](assets/A_ID132_Pozahualiz-xiuhtontli.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
