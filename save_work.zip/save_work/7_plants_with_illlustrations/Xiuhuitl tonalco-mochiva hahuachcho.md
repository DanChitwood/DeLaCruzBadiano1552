Variants  

![D_ID184_Xiuhuitl_tonalco-mochiva_hahuachcho.png](assets/D_ID184_Xiuhuitl_tonalco-mochiva_hahuachcho.png)  
Leaf traces by: Dan Chitwood, Michigan State University, USA  
