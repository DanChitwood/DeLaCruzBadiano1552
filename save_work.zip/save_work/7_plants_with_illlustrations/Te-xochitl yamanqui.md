Variants  

![M_ID053_Te-xochitl_yamanqui.png](assets/M_ID053_Te-xochitl_yamanqui.png)  
Leaf traces by: Mariana Ruíz Amaro, UNAM ENES León, México  
