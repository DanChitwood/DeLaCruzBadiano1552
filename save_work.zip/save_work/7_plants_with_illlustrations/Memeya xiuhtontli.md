Variants  

![A_ID114_Memeya_xiuhtontli.png](assets/A_ID114_Memeya_xiuhtontli.png)  
Leaf traces by: Alejandra Rougon, UNAM ENES León, México  
