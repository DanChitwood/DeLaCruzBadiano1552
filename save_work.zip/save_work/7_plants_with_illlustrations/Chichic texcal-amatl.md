Variants  

![K_ID089_Chichic_texcal-amatl.png](assets/K_ID089_Chichic_texcal-amatl.png)  
Leaf traces by: Kylie DeViller, Acadia University, Canada  
