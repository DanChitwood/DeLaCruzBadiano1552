Variants: tecpatl  

## Subchapter 6f  
**For scrofulous tumors.** One scrofulous is relieved of the ailment if a plaster is applied to the neck, made of plants growing in a burned over thicket of bushes or reeds, the [tolova-xihuitl]('Tolohua_xihuitl.md'), the [tonatiuh yxiuh]('Tonatiuh_yxiuh.md'), the root of the [tecpatl]('Tecpatl.md'), and the leaves of bramble bushes; crush these with the stone found in a swallow’s stomach, with his blood.    
[https://archive.org/details/aztec-herbal-of-1552/page/41](https://archive.org/details/aztec-herbal-of-1552/page/41)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
