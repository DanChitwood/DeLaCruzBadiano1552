Variants: tlapatl  

## Subchapter 3a  
**On festering in the ears, and deafness or stoppage.** Festering in the ears will be helped the most by instilling the root of the [maza-yelli]('Maza-yelli.md'), seeds of the [xoxouhqui-patli]('xoxouhca-patli.md') plant, some leaves of the [tlaquilin]('Tlaquilin.md') with a grain of salt in hot water. Also the leaves of two bushes, rubbed up, are to be smeared below the ears; these bushes are called [tolova]('Tolohua_xihuitl.md') and [tlapatl]('Tlapatl.md'); also the precious stones [tetlahuitl]('tetlahuitl.md'), [tlacalhuatzin]('tlacal-huatzin.md'), [eztetl]('eztetl.md'), xoxouhqui chalchi-huitl, with the leaves of the [tlatlanquaye]('Tlatlanquaye.md') tree macerated in hot water, ground together and put in the stopped up ears, willopen them.    
[https://archive.org/details/aztec-herbal-of-1552/page/22](https://archive.org/details/aztec-herbal-of-1552/page/22)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
