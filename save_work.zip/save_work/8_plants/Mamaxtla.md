Variants: mamaxtla  

## Subchapter 8c  
**The bladder-wort.** When the flow of the urine is shut off, to open it take the roots of the plants [mamaxtla]('Mamaxtla.md') and [cohuanene-pilli]('Coanenepilli.md'), the tlatlauhqui amoxtli, the very white flower [yollo-xochitl]('Yollo-xochitl.md'), and the tail of a sucking puppy; grind these up in acrid tasting water, macerate the well-known [chian]('Chian.md') seed therein, and administer it. The abdomen is also to be washed out with the root of the herb [ohua-xocoyolin]('Ohua-xoxocoyolin.md') crushed in hot water, and the juice given through a clyster. If this medicine avails nothing it will be necessary to take the pith of an extremely slender palm, covered with thin cotton and smeared with honey and the crushed root of the herb [huihuitz-mallotic]('Huihuitz-mallotic.md'), and this cautiously inserted into the virile member. If this is done the stopped urine will be freed.    
[https://archive.org/details/aztec-herbal-of-1552/page/59](https://archive.org/details/aztec-herbal-of-1552/page/59)  

## Subchapter 8d  
**Difficulty in passing the urine.** Against difficulty in urination, a liquor prepared from the flowers [tetzmi-xochitl]('Tetzmi-xochitl.md'), [tlaco-izqui-xochitl]('Tlaco-izqui-xochitl.md'), [yollo-xochitl]('Yollo-xochitl.md'), the[mamaxtla]('Mamaxtla.md') root, red earth and [eztetl]('eztetl.md'), white earth, drunk in water, will be of avail. Also place on the stomach a stone found in the stream, in which pearls (uniones) appear.    
[https://archive.org/details/aztec-herbal-of-1552/page/60](https://archive.org/details/aztec-herbal-of-1552/page/60)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
