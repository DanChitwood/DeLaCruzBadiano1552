Variants: tzihuac-copalli  

## Subchapter 9l  
**Swelling of the veins after phlebotomy.** When a vein comes to swelling after being cut, the bushes[tzihuac-copalli]('Tzihuac-copalli.md') and [tlaco-eca-patli]('Tlaco-ecapatli.md'), [tetzmitl]('Tetzmitl.md'), the root of the plant[tlanen-popoloa]('Tla-nen-popoloua.md'), the leaves of the herb [quauh-yyauhtli]('Quauh-yyauhtli.md') andahuiyac tlatlanquaye, with the herb [coyo-xihuitl]('Coyo-xihuitl.md') are ground together with yolk of egg, in which water breathing the odor of frankincense is then poured, and the incised vein soaked with this liquor.    
[https://archive.org/details/aztec-herbal-of-1552/page/86](https://archive.org/details/aztec-herbal-of-1552/page/86)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
