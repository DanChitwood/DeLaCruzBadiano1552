Variants: chicom-catl  

## Subchapter 9f  
**Remedy for lesions of the body.** Lesions caused by rough treatment should be treated with a poultice made from [tlazo-teo-zacatl]('Tlazol-teo-zacatl.md'), [centzon-xochitl]('Centzon-xochitl.md'), [xiuh-tontli]('Xiuhtontli.md'), [a-xocotl]('A-xocotl.md'), [tlayapaloni]('Tla-yapaloni.md'), [xiuhtontli]('Xiuhtontli.md'), moss from some tree, cypress nuts, seeds of the nettle, and the tree [ayauh-quahuitl]('Ayauh-quahuitl.md'). Let the ill-treated one drink a broth carefully prepared from the root of the [coanenepilli]('Coanenepilli.md'), tlanextia xihuitl, [chicom-catl]('Chicom-acatl.md'), the flower of the [a-xocotl]('A-xocotl.md') and [izqui-xochitl]('Izqui-xochitl.md'), [tetlahuital]('tetlahuitl.md'), [eztetl]('eztetl.md'), [te-amoxtli]('Te-amoxtli.md'), the blood of an aquatic bird, the [huexo-canauhtli]('huexo-canauhtli.md'), and some [tlatlanquaye]('Tlatlanquaye.md') leaves, all of which are to be ground up in acidulous water.    
[https://archive.org/details/aztec-herbal-of-1552/page/80](https://archive.org/details/aztec-herbal-of-1552/page/80)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
