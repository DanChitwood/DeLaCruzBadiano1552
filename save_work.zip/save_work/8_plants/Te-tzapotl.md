Variants: te-tzapotl  

## Subchapter 8a  
**Curation of the pubis.** When this part feels pain, let it be anointed with liquor expressed and prepared from the bark and leaves of the tree[macpal-xochitl]('Macpal-xochitl.md'), the thorny plants [tolohua-xihuitl]('Tolohua_xihuitl.md') and [xiuh-tontli]('Xiuhtontli.md'), Indian knives, flints, the fruit we call [te-tzapotl]('Te-tzapotl.md') and the stone [te-xoxoctli]('te-xoxoctli.md'), ground up in the blood of a swallow, a lizard and a mouse. You must remember to heat this liquid. Also if a tumor or the pain burns severely, do not hesitate on section; the cut you must purify and anoint with a liquid drawn from the roots of the herb [tlal-huaxin]('Tlal-huaxin.md'), ground up in yolk of egg.    
[https://archive.org/details/aztec-herbal-of-1552/page/57](https://archive.org/details/aztec-herbal-of-1552/page/57)  

## Subchapter 8b  
**The argemon or groin plant.** The plants xiuhtontli tlanen-popoloua and those that grow in a garden once burned over, the fruit [te-tzapotl]('Te-tzapotl.md'), brambles, [te-amoxtli]('Te-amoxtli.md'), the stone found in a swallow’s stomach, ground in swallow’s and mouse’s blood, and applied, allay pains of the groin and reduce swellings.    
[https://archive.org/details/aztec-herbal-of-1552/page/58](https://archive.org/details/aztec-herbal-of-1552/page/58)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
