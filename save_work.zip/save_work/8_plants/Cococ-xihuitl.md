Variants: cococ-xiuhuitl  

## Subchapter 7i  
**Tumor of the stomach.** For a tumor of the abdomen or stomach, make a preparation from the leaves of the [xiuhtontli]('Xiuhtontli.md') and the root of the [tlatlanquaye]('Tlatlanquaye.md'), the [copaliyac-xiuhtontli]('Copaliyac-xiuhtontli.md') and the alectorium or gem found in the maw of a cock, ground together in the finest Indian wine; also let him be given through the rectum a purge for the bowel made from the root of the [cococ-xiuhuitl]('Cococ-xihuitl.md'), Indian pepper, salt, nitre and the alectorium.    
[https://archive.org/details/aztec-herbal-of-1552/page/52](https://archive.org/details/aztec-herbal-of-1552/page/52)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
