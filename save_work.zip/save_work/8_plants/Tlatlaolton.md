Variants: tlatlaolton  

## Subchapter 7b  
**For pain in the chest.** Pain in the chest is relieved by the plants [tetlahuitl]('Tetlahuitl.md')and [teo-iztaquilitl]('Teo-iztaquilitl.md')growing on a rock, together with the stone [tlacahuatzin]('tlacal-huatzin.md'), and red and white earth triturated in water; the skin of a lion is also to be burned and its broth drunk; the chest is to be rubbed with the juice expressed from the herb [tzitzicton]('Tzitzicton.md'), [tlatlaolton]('Tlatlaolton.md'), [ayauhtli]('Ayauhtli.md'), cypress seeds or nuts, and the [itzcuinpatli]('Itzquin-patli.md')with the [huacal-xochitl]('Huacal-xochitl.md') and [papalo-quilitl]('Papalo-quilitl.md').    
[https://archive.org/details/aztec-herbal-of-1552/page/46](https://archive.org/details/aztec-herbal-of-1552/page/46)  

## Subchapter 8k  
**Against lassitude.** One fatigued will be restored if the feet be bathed in choice liquor, with the [ahuiyac-xihuitl]('Ahuiyac-xihuitl.md') or [tlatlanquaye]('Tlatlanquaye.md'), [tlatlaolton]('Tlatlaolton.md'), [itzcuin-patli]('Itzquin-patli.md'), [xiuh-ecapatli]('Eca-patli.md'), [iztauh-yatl]('Iztauyattl.md'), the [huitzihtzil-xochitl]('Huitzihtzil-xochitl.md')flower, and the stones [tetlahuitl]('tetlahuitl.md'), [tlaca-huatzin]('tlacal-huatzin.md') and [eztetl]('eztetl.md'), to be crushed in hot water.    
[https://archive.org/details/aztec-herbal-of-1552/page/66](https://archive.org/details/aztec-herbal-of-1552/page/66)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
