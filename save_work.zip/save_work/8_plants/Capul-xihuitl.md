Variants: capul-xihuitl  

## Subchapter 7k  
**Dysentery.** The following serve well against dysentery: leaves of the herb [tlacomatl]('Tlaco-amatl.md'), leaves of the [xa-xocotl]('Xa-xocotl.md'), almonds, laurel, almond husks, pine bark, the [quetzal-ylin]('Quetzal-ylin.md'), the [ylin]('Ylin.md'), [capul-xihuitl]('Capul-xihuitl.md') and alectorium, deer’s horn burned to ashes, greens and grain ground up in hot water. The liquor is then to be taken into the rear parts by injection.    
[https://archive.org/details/aztec-herbal-of-1552/page/53](https://archive.org/details/aztec-herbal-of-1552/page/53)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
