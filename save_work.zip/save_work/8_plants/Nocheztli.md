Variants: nocheztli  

## Subchapter 6c  
**For swollen jaws.** Swollen jaws are helped by taking in water the juice of crushed [tememetla]('Te-memetla.md') leaves, the pith of the [te-xiyotl]('Te-xiyotl.md') and white earth, the liquor whereof is sub-acid, with the gummy twigs bearing the glutinous tears we call [nocheztli]('Nocheztli.md'). For those who cannot open the mouth the root of the [tlatlacotic]('Tlatlacotic.md') crushed in tepid water helps greatly; if he drinks this liquor, making him promptly vomit, the freed mucus will open the mouth.    
[https://archive.org/details/aztec-herbal-of-1552/page/38](https://archive.org/details/aztec-herbal-of-1552/page/38)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
