Variants: piciyetl, pizietl  

## Subchapter 7l  
**For a rumbling in the abdomen.** For one whose intestines rumble because of some flux in the abdomen, let him take by means of an ear syringe (clyster oriculario), a liquor prepared from leaves of the [tlatlanquaye]('Tlatlanquaye.md') herb, the bark of the [quetzal-ylin]('Quetzal-ylin.md'), [iztac-oco-xochitl]('Iztac_oco-xochitl.md') leaves, and the herbs [tlanexti-xiuhtontli]('Tlanextia_xiuhtontli.md'), [elo-zacatl]('Elo-zacatl.md'), the tree [tlanextia-quahuitl]('Tlanextia_quahuitl.md'), ground up in acidulous water with ashes, a little honey, salt, pepper, alectorium and finally [pizietl]('Piciyetl.md') or tobacco.    
[https://archive.org/details/aztec-herbal-of-1552/page/54](https://archive.org/details/aztec-herbal-of-1552/page/54)  

## Subchapter 9h  
**For recurrent disease.** Let one relapsing in sickness drink, before a meal, a little of the latex like milk, expressed from the [teo-amatl]('Teo-amatl.md'), that he may vomit. On the third or fourth day let him drink a potion formed from [tonatiuh-yxiuh]('Tonatiuh_yxiuh.md') root, [tlatlanquaye]('Tlatlanquaye.md') and also [tlanexti-yxiuh]('Tlanextia-yxiuh.md') root, ground up in tepid water. Third let him drink of the [cuecuetz-patli]('Cuecuetz-patli.md') root crushed in our wine. Let him drink this as he enters the bath, and then on coming out be anointed with the liquor of ground [teo-amatl]('Teo-amatl.md') roots. The bowel should be twice cleared with a clyster, first with a liquor from [ohua-xocoyolin]('Ohua-xoxocoyolin.md')root crushed in hot water, and this even though he partakes of some food; this healthful juice will throw out pus from the abdomen. The second time, a few days later, made of the intoxicating plant we call [piciyetl]('Piciyetl.md'), salt, our black pepper, and light colored pepper.    
[https://archive.org/details/aztec-herbal-of-1552/page/82](https://archive.org/details/aztec-herbal-of-1552/page/82)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
