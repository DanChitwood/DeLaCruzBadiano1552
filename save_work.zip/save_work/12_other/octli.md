Variants: octli  

## Subchapter 10h  
**Lousy distemper.** Numerous lice will not seek the body while one drinks a liquor derived from new deer’s horn ground in our wine, or [octli]('octli.md'), of the best kind. It is also to be drunk frequently,    
[https://archive.org/details/aztec-herbal-of-1552/page/101](https://archive.org/details/aztec-herbal-of-1552/page/101)  

## Subchapter 11a  
**For recent parturition.** If the woman suffers difficulty in the bringing forth, then that she may give forth the fetus with little effort, let her drink medicines made from the bark of the tree[quauh-alahuac]('Quauh-alahuac.md') and the plant [cihua-patli]('Cihua-patli.md'), the small stone [eztetl]('eztetl.md'), and the tail of the small animal called [tlaquatzin]('tlaquatzin.md'). Let her hold the plant [tlanextia]('Tlanextia_xiuhtontli.md') in her hand. Also the hairs and bone of an ape, the wings of an eagle, the tree [a-huexotl]('Quetzal-ahuexotl.md'), the skin of a deer, gall of a cock, also of a hare, and onions put in the sun are to be burned together; to these are to be added salt, the fruit we call [nochtli]('Nochtli.md'), and the pulque we call [octli]('octli.md'). The above are to be heated and used for anointing. Let her eat the cooked flesh of a wolf, and greenstone together with bright green pearl be bound on her back. She may also drink the juice of ground up kite and goose flesh, and the tail of the tlaquauzin, in our sweet wine; also take the root of the [xal-tomatl]('Xal-tomatl.md'), the tail of the [tlaquatzin]('tlaquatzin.md'), and leaves of the [cihua-patli]('Cihua-patli.md'), grind them up, and wet the womb. Also grind the tail of a suckling [tlaquatzin]('tlaquatzin.md') in water, with the plant [cihua-patli]('Cihua-patli.md'), with which let the body be purged, it being given by a clyster.    
[https://archive.org/details/aztec-herbal-of-1552/page/106](https://archive.org/details/aztec-herbal-of-1552/page/106)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
