Variants: hoxitl  

## Subchapter 8i  
**Cracks in the soles of the feet.** Cracks in the soles of the feet are cured by a salve prepared from the herb [tolohua-xihuitl]('Tolohua_xihuitl.md'), blood of a cock, resin, the resinous humor we call [hoxitl]('hoxitl.md'), the which muist be heated.    
[https://archive.org/details/aztec-herbal-of-1552/page/64](https://archive.org/details/aztec-herbal-of-1552/page/64)  

![Z_ID018_Ayauh-quahuitl.png](assets/Z_ID018_Ayauh-quahuitl.png)  
Leaf traces by: Zoë Migicovsky, Acadia University, Canada  
